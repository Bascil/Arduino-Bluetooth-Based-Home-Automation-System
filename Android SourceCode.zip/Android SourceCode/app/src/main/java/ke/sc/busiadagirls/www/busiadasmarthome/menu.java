package ke.sc.busiadagirls.www.busiadasmarthome;



import android.app.Activity;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import android.widget.Toast;
import android.widget.ToggleButton;

import java.io.IOException;

import java.io.OutputStream;

import java.util.UUID;





public class menu extends Activity {

	Button  Abt,Discnt;
	String address = null;
	private ProgressDialog progress;
	BluetoothAdapter myBluetooth = null;
	BluetoothSocket btSocket = null;
	private boolean isBtConnected = false;
	//SPP UUID. Look for it
	static final UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");


	OutputStream mmOutputStream;

	int stat;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.rooms);



		Discnt = (Button)findViewById(R.id.discnt);
		Abt = (Button)findViewById(R.id.abt);

		final ToggleButton light1 = (ToggleButton) findViewById(R.id.toggleButton1);

		new ConnectBT().execute(); //Call the class to connect

		light1.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (light1.isChecked()) {
					if (stat == 1){
						try {
							mmOutputStream.write('1');
						}catch (IOException e) {
							// TODO Auto-generated catch block
							Toast.makeText(menu.this,
									"Connection not established with your home",
									Toast.LENGTH_LONG).show();
							e.printStackTrace();
						}
					} else
						Toast.makeText(menu.this,
								"Connection not established with your home",
								Toast.LENGTH_LONG).show();
				}else {
			if (stat == 1){
				try {
					mmOutputStream.write('2');
				}catch (IOException e) {
					// TODO Auto-generated catch block
					Toast.makeText(menu.this,
							"Connection not established with your home",
							Toast.LENGTH_LONG).show();
					e.printStackTrace();
				}
			} else
				Toast.makeText(menu.this,
						"Connection not established with your home",
						Toast.LENGTH_LONG).show();
		}
	}
});


		final ToggleButton light2 = (ToggleButton) findViewById(R.id.ToggleButton01);
		light2.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (light2.isChecked()) {
					if (stat == 1){
						try {
							mmOutputStream.write('3');
						}catch (IOException e) {
							// TODO Auto-generated catch block
							Toast.makeText(menu.this,
									"Connection not established with your home",
									Toast.LENGTH_LONG).show();
							e.printStackTrace();
						}
					} else
						Toast.makeText(menu.this,
								"Connection not established with your home",
								Toast.LENGTH_LONG).show();
				}else {
					if (stat == 1){
						try {
							mmOutputStream.write('4');
						}catch (IOException e) {
							// TODO Auto-generated catch block
							Toast.makeText(menu.this,
									"Connection not established with your home",
									Toast.LENGTH_LONG).show();
							e.printStackTrace();
						}
					} else
						Toast.makeText(menu.this,
								"Connection not established with your home",
								Toast.LENGTH_LONG).show();
				}
			}
		});

		final ToggleButton light3 = (ToggleButton) findViewById(R.id.ToggleButton02);
		light3.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (light3.isChecked()) {
					if (stat == 1){
						try {
							mmOutputStream.write('5');
						}catch (IOException e) {
							// TODO Auto-generated catch block
							Toast.makeText(menu.this,
									"Connection not established with your home",
									Toast.LENGTH_LONG).show();
							e.printStackTrace();
						}
					} else
						Toast.makeText(menu.this,
								"Connection not established with your home",
								Toast.LENGTH_LONG).show();
				}else {
					if (stat == 1){
						try {
							mmOutputStream.write('6');
						}catch (IOException e) {
							// TODO Auto-generated catch block
							Toast.makeText(menu.this,
									"Connection not established with your home",
									Toast.LENGTH_LONG).show();
							e.printStackTrace();
						}
					} else
						Toast.makeText(menu.this,
								"Connection not established with your home",
								Toast.LENGTH_LONG).show();
				}
			}
		});




	}
	// fast way to call Toast
	private void msg(String s)
	{
		Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
	}



	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		super.onCreateOptionsMenu(menu);
		MenuInflater h= getMenuInflater();
		h.inflate(R.menu.hardmenu,menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch(item.getItemId())
		{
			case R.id.about:
				startActivity(new Intent(this, AboutActivity.class));
				return true;
		}
		return false;
	}


	private class ConnectBT extends AsyncTask<Void, Void, Void>  // UI thread
	{
		private boolean ConnectSuccess = true; //if it's here, it's almost connected

		@Override
		protected void onPreExecute()
		{
			progress = ProgressDialog.show(menu.this, "Connecting...", "Please wait!!!");  //show a progress dialog
		}

		@Override
		protected Void doInBackground(Void... devices) //while the progress dialog is shown, the connection is done in background
		{
			try
			{
				if (btSocket == null || !isBtConnected)
				{
					myBluetooth = BluetoothAdapter.getDefaultAdapter();//get the mobile bluetooth device
					BluetoothDevice dispositivo = myBluetooth.getRemoteDevice(address);//connects to the device's address and checks if it's available
					btSocket = dispositivo.createInsecureRfcommSocketToServiceRecord(myUUID);//create a RFCOMM (SPP) connection
					BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
					btSocket.connect();//start connection
				}
			}
			catch (IOException e)
			{
				ConnectSuccess = false;//if the try failed, you can check the exception here
			}
			return null;
		}
		@Override
		protected void onPostExecute(Void result) //after the doInBackground, it checks if everything went fine
		{
			super.onPostExecute(result);

			if (!ConnectSuccess)
			{
				msg("Connection Failed. Invalid Bluetooth module? Try again.");
				finish();
			}
			else
			{
				msg("Connected.");
				isBtConnected = true;
			}
			progress.dismiss();
		}
	}




}